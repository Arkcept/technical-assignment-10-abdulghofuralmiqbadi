import 'package:flutter/material.dart';

class PageSiji extends StatefulWidget {
  const PageSiji({super.key});

  @override
  State<PageSiji> createState() => _PageSijiState();
}

class _PageSijiState extends State<PageSiji> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Home'),
      ),
      body: Container(
        child: Image.network(
          'https://picsum.photos/1600/900.jpg',
          width: 200,
          height: 200,
        ),
      ),
    );
  }
}
