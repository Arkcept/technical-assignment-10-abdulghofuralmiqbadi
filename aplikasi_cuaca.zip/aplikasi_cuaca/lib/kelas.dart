class Kelas {
  String kelas;
  String name;
  String description;
  String lk;
  String pr;
  String wk;

  Kelas({
    required this.kelas,
    required this.name,
    required this.description,
    required this.lk,
    required this.pr,
    required this.wk,
  });
}

var KelasList = [
  Kelas(
    kelas: '12 IPA 4',
    name: 'Inforsa',
    description: 'Kelas yang berada di Angktan 28',
    lk: '11',
    pr: '18',
    wk: 'Bu Yatik',
  ),
  Kelas(
    kelas: '12 IPs 3',
    name: 'Infasa',
    description: 'Kelas yang berada di Angktan 28',
    lk: '8',
    pr: '23',
    wk: 'Pak Adi',
  ),
];
